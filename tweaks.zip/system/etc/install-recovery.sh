#!/system/bin/sh
/system/bin/sysinit

# Init.d support
# Ryuinferno @ XDA 2012
run-parts /system/etc/init.d/

